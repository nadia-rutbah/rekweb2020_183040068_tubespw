<?php 
session_start();

if( !isset($_SESSION["login"]) ) {
	header("Location: login.php");
	exit;
}

require 'functions.php';
$mobil = query("SELECT * FROM mobil");

// tombol cari ditekan
if( isset($_POST["cari"]) ) {
	$mobil = cari($_POST["keyword"]);
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link href="assets/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
		<a class="navbar-brand btn btn-danger" href="logout.php">Logout</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
	    <span class="navbar-toggler-icon"></span>
		</button>

	  	<div class="collapse navbar-collapse" id="navbarSupportedContent">
	    	<ul class="navbar-nav mr-auto">
	    	</ul>
		    <form class="form-inline my-2 my-lg-0" action="" method="post">
		      	<input type="text" name="keyword" size="40" autofocus placeholder="cari" autocomplete="off" id="keyword" class="form-control mr-sm-2">
				<button type="submit" name="cari" id="tombol-cari" class="btn btn-outline-success my-2 my-sm-0">Cari!</button>
				<div class="spinner-grow text-light" role="status">
				  <span class="sr-only">Loading...</span>
				</div>
		    </form>
	  </div>
	</nav>
	<!-- container -->
	<div class="container">
		<h1>Daftar Mobil</h1>
		
		<a href="tambah.php" >
			<button class="btn btn-info">(+)Tambah data</button>
		</a>

		<div id="container" class="container my-3">
		<table class="table">
			<thead>
			<tr>
				<th scope="col">No.</th>
				<th scope="col">Aksi</th>
				<th scope="col">Gambar</th>
				<th scope="col">Merk</th>
				<th scope="col">Tipe</th>
				<th scope="col">Warna</th>
				<th scope="col">Tahun</th>
			</tr>
			</thead>
			<thead>
			<?php $i = 1; ?>
			<?php foreach( $mobil as $m ) : ?>
			<tr>
				<td scope="row"><?= $i; ?></td>
				<td>
					<a href="ubah.php?id=<?= $m["id"]; ?>" class="btn btn-info btn-circle btn-sm">
						<i class="fas fa-edit"></i>
					</a>
					<a href="hapus.php?id=<?= $m["id"]; ?>" class="btn btn-danger btn-circle btn-sm" onclick="return confirm('Data akan dihapus dan tidak bisa dikembalikan lagi. Apakah anda yakin ingin menghapus ini?');">
						<i class="fas fa-trash"></i>
					</a>
				</td>
				<td><img src="assets/img/<?= $m["gambar"]; ?>" width="50" class="img-thumbnail"></td>
				<td><?= $m["merk"]; ?></td>
				<td><?= $m["tipe"]; ?></td>
				<td><?= $m["warna"]; ?></td>
				<td><?= $m["tahun"]; ?></td>
			</tr>
			<?php $i++; ?>
			<?php endforeach; ?>
			</thead>
			
		</table>
		</div>		
	</div>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script src="assets/js/jquery-3.2.1.min.js"></script>
<script src="assets/js/script.js"></script>
</body>
</html>