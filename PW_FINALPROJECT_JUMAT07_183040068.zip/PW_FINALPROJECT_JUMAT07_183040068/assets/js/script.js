$(document).ready(function() {
    // hilangkan tombol cari
    $('#tombol-cari').hide();
    // hilangkan spinner
    $('.spinner-grow').hide();

    // event ketika keyword ditulis
    $('#keyword').on('keyup', function() {
        // munculkan icon loading
        $('.spinner-grow').show();

        // ajax menggunakan load
        // $('#container').load('ajax/elektronik.php?keyword=' + $('#keyword').val());

        // $.get()
        $.get('ajax/elektronik.php?keyword=' + $('#keyword').val(), function(data) {

            $('#container').html(data);
            $('.spinner-grow').hide();

        });

    });

});
