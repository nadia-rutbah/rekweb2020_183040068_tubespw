<?php 
usleep(500000);
require '../functions.php';

$keyword = $_GET["keyword"];

$query = "SELECT * FROM elektronik
            WHERE
          type LIKE '%$keyword%' OR
          merek LIKE '%$keyword%' OR
          jenis_product LIKE '%$keyword%' OR
          harga LIKE '%$keyword%'
        ";
$elektronik = query($query);
?>
<table class="table">
    <thead>
    <tr>
        <th scope="col">No.</th>
        <th scope="col">Aksi</th>
        <th scope="col">Gambar</th>
        <th scope="col">Merek</th>
        <th scope="col">Type</th>
        <th scope="col">Jenis Product</th>
        <th scope="col">Harga</th>
    </tr>
    </thead>
    <thead>
    <?php $i = 1; ?>
    <?php foreach( $elektronik as $row ) : ?>
    <tr>
        <td scope="row"><?= $i; ?></td>
        <td>
            <a href="ubah.php?id=<?= $row["id"]; ?>" class="btn btn-info btn-circle btn-sm">
                <i class="fas fa-edit"></i>
            </a>
            <a href="hapus.php?id=<?= $row["id"]; ?>" class="btn btn-danger btn-circle btn-sm" onclick="return confirm('yakin?');">
                <i class="fas fa-trash"></i>
            </a>
        </td>
        <td><img src="img/<?= $row["gambar"]; ?>" width="50"></td>
        <td><?= $row["merek"]; ?></td>
        <td><?= $row["type"]; ?></td>
        <td><?= $row["jenis_product"]; ?></td>
        <td><?= $row["harga"]; ?></td>
    </tr>
    <?php $i++; ?>
    <?php endforeach; ?>
    </thead>
    
</table>